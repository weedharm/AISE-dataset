package org.eclipse.birt.report.designer.data.ui.dataset;



public class AdvancedColumnDefPage extends ColumnDefPage
{

	public AdvancedColumnDefPage( )
	{
		super( );
	}
	
}
