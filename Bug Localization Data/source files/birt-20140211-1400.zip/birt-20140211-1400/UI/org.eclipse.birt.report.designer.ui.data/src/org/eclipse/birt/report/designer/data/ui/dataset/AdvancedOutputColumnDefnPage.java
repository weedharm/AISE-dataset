package org.eclipse.birt.report.designer.data.ui.dataset;


public class AdvancedOutputColumnDefnPage extends OutputColumnDefnPage
{
	
	public AdvancedOutputColumnDefnPage( )
	{
		super( );
	}


}
