package org.eclipse.birt.report.designer.data.ui.dataset;


public class AdvancedDataSetSettingsPage extends DataSetSettingsPage
{

	public AdvancedDataSetSettingsPage( )
	{
		super( );
	}

}
