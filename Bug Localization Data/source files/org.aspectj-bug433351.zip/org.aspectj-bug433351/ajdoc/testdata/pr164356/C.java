public class C {

    // foo's ordinary comment
    /**
     * description of foo
     */
    public void foo() {
    }

    //************
    /**
     * description of bar
     */
    public void bar() {
    }
    
    //******* description of goo
    public void goo() {
    }
    
    /*---------------------------*/
    /**
     * description of bas
     */
    public void bas() {
    }

}
