/*
 * Created on Jan 12, 2005
 */

package foo;

/**
 * @author Mik Kersten
 */
public class NoMembers {

}
