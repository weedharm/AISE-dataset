
package foo;

public interface InterfaceI { 
	void foo();
} 