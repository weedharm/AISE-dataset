
package fluffy;
 
public class Fluffy {

	void doIt() { }
	
}
 