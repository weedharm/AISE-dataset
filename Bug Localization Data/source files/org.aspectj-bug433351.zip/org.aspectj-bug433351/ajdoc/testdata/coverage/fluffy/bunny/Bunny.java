
package fluffy.bunny;
 
public class Bunny {

	void doIt() { }
	
}
 