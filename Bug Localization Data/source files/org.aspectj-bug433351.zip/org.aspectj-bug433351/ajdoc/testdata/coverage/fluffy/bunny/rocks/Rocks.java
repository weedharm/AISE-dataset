
package fluffy.bunny.rocks;
 
public class Rocks {

	void doIt() { }
	
}
 