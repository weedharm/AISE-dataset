package pack;

public class C {

	public int x = 2;
	
	void method() {
	}
	
	public String method1() {
		return "";
	}
	
	private String method2(){
		return "";
	}
	
	public void method3(String s) { 
	}
	
}
