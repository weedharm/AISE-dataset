public class C {
	
	public void foo() {
	}
	
}
