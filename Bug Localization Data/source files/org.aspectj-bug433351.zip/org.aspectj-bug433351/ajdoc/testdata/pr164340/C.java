public class C {

	/**
	 * This is a constructor
	 */
	public C() {
	}

	/**
	 * This is method foo
	 */
	public void foo() {
	}

}
