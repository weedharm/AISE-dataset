package pack;

public enum EnumWithMethods {
	
	A;
	
	EnumWithMethods() {
		
	}
	
}
