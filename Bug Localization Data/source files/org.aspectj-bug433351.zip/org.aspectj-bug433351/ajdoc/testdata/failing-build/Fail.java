
class Mumble {

	this fails
}