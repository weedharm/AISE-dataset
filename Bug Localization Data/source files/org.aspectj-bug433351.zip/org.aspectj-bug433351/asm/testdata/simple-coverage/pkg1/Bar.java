
package pkg1;

public class Bar {
//  int x = b;
}
