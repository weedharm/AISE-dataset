
package pkg1.subpkg;

public class Bar {
//  int x = b;
}
