public class Foo {
//  int x = b;
   static class Mumble {
      String name;
   
      class Gumble {
         int b;
      }
   }
   //aspect MemberAspect { } 

   interface MemberI { } 
}
