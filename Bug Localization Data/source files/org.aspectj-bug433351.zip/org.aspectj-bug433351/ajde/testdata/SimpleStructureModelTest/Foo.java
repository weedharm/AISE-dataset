public class Foo {
//  int x = b
}