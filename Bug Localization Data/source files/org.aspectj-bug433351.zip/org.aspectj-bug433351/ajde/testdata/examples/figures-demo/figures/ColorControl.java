/*
Copyright (c) 2002 Palo Alto Research Center Incorporated. All Rights Reserved.
 */

package figures;

import java.awt.Color;
import figures.FigureElement;

public aspect ColorControl {
    public static void setFillColor(FigureElement fe, Color color) {
	// fill in here
    }

    public static void setLineColor(FigureElement fe, Color color) {
	// fill in here
    }

    // fill in here
}
