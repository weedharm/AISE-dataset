/*
Copyright (c) 2002 Palo Alto Research Center Incorporated. All Rights Reserved.
 */
 
package figures;

public class Canvas {
	public static void updateHistory() {
		// not implemented	
	}
}
