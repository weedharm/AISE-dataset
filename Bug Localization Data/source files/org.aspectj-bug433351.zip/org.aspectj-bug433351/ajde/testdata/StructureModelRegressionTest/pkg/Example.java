package pkg;

class Example {
	public void foo() {
	}
	
	public int goo() {
		return 37;
	}
	
	double d = 37;
	
	Example(int i) {
		d = d + i;
	}
}