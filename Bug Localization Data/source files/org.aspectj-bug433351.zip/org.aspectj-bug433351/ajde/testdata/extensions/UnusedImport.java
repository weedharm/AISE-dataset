import java.util.List;
import java.util.Vector;
import java.util.ArrayList;

public class UnusedImport {
  public static void main(String[] argv) {
    Vector v = new Vector();
  }
}
