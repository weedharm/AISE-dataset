
package configs.moduleB;

class B1 { } 