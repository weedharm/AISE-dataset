package configs.moduleB.moduleC;

class C2 { } 