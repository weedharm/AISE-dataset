package configs.moduleB.moduleC;

class C1 { } 