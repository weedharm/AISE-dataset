package configs.moduleB;

class B2 { } 