package configs.moduleB;

class B3 { } 
