// A simple class, interfered with by all sorts of advice !

public class Simple {
	
	public void m1() {
		
	}
	
	public String m2() {
		return "a";
	}
	
	public static void main(String[] argv) {
		
	}
	
	private void mSecret() {
		
	}
	
}