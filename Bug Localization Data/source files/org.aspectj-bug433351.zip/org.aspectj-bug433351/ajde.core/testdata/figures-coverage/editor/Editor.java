
package editor;

class Editor { }
