import java.io.IOException;

/*
 * Created on 30-Jul-03
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author websterm
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Main {

	public void println () {
		System.out.println("Main.");
	}

	public static void main(String[] args) throws IOException {
		new Main().println();
	}
}
