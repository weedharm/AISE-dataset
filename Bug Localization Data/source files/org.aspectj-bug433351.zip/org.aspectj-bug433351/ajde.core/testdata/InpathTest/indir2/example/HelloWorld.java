package example;

public class HelloWorld {

  public static void say(String msg) {
    System.err.println(msg);
  }

  public static void main(String []argv) {
    say("hello world");
  }
}
